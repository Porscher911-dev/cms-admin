const { Client } = require('ssh2');
const conn = new Client();

const script = `
echo "=== Test POST Chat API ==="
curl -X POST http://127.0.0.1:3000/api/chat \\
  -H "Content-Type: application/json" \\
  -d '{"senderName":"Test","senderRole":"DIRECTOR","content":"Hello World"}'

echo ""
echo "=== Test GET Chat API ==="
curl -s http://127.0.0.1:3000/api/chat?role=DIRECTOR
`;

conn.on('ready', () => {
  console.log('Client :: ready');
  conn.exec(script, (err, stream) => {
    if (err) throw err;
    stream.on('close', (code, signal) => {
      console.log('Stream :: close :: code: ' + code + ', signal: ' + signal);
      conn.end();
    }).on('data', (data) => {
      process.stdout.write('STDOUT:\n' + data);
    }).stderr.on('data', (data) => {
      process.stderr.write('STDERR:\n' + data);
    });
  });
}).on('error', (err) => {
  console.error('SSH Connection Error:', err);
}).connect({
  host: '223.130.11.31',
  port: 22,
  username: 'root',
  password: 'AZvpsr69Dn@@8B8'
});
